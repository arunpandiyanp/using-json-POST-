//
//  login.h
//  loginscreen
//
//  Created by Dinesh Jaganathan on 21/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface login : UIViewController{
    
    
    
    IBOutlet  UIButton *loged;
    
    
    
    
    
}

-(IBAction)loggedbtn:(id)sender;

@end